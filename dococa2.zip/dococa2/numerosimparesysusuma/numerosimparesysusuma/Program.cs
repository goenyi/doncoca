﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace SUMAIMPARES 
{
    class Program 
    { 
        static void Main(string[] args)
        {
            menu();
        }
        static void imparaque()
        { 
            byte NUM, I; 
            int SUMP = 0; 
            string linea; 
            Console.Write("NÚMERO MÁXIMO: "); 
            linea = Console.ReadLine(); 
            NUM = byte.Parse(linea); 
            for (I = 1; I <= NUM; I += 2) 
            { SUMP = SUMP + I; }  
            Console.WriteLine("suma de numeros impares : " + SUMP);
            if (SUMP > 0) ;
            Console.WriteLine("numeros ingresados : " + linea);// no especifica el ejercicio si solo se quiere imprimir los numeros impares o todos en total... :)
            Console.Write("Pulse una Tecla:");
            Console.ReadLine(); 
            Console.ReadKey();  
    }

        static void menu()
        {
            int opcion;
            Console.WriteLine("MENU PRINCIPAL");
            Console.WriteLine("1. numero impar y su cantidad");
            Console.WriteLine("2. salir");
            Console.WriteLine("Elija una Opcion");
            opcion = Convert.ToInt32(Console.ReadLine());
            switch (opcion)
            {
                case 1: imparaque(); menu(); break;
                case 2: Console.WriteLine("Salida del Sistema"); Console.ReadKey(); break;
                default: Console.WriteLine("Opcion Invalida"); Console.ReadKey(); menu(); break;
            }
        }

}
}