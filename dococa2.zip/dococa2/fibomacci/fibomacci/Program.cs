﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace SERIE_DE_FIBONACCI
{
    class Program
    {
        static void Main(string[] args)
        {
            menu();
        }
        static void fibipapa()
        {
            byte CAN, K;
            int A, B, C;
            string linea;
            Console.Write("CUANTOS NÚMEROS: "); linea = Console.ReadLine();
            CAN = byte.Parse(linea);
            A = 1; B = 1;
            Console.Write(A + " " + B + " ");
            for (K = 3; K <= CAN; K++)
            {
                C = A + B; Console.Write(C + " ");
                //INTERCAMBIO DE VALORES             
                A = B;
                B = C;
            }
            Console.WriteLine();
            Console.Write("Pulse una Tecla:");
            Console.ReadLine();

            Console.ReadKey();
        }
        static void menu()
        {
            int opcion;
            Console.WriteLine("MENU PRINCIPAL");
            Console.WriteLine("1. Serie de numero fibonacci");
            Console.WriteLine("2. salir");
            Console.WriteLine("Elija una Opcion");
            opcion = Convert.ToInt32(Console.ReadLine());
            switch (opcion)
            {
                case 1: fibipapa(); menu(); break;
                case 2: Console.WriteLine("Salida del Sistema"); Console.ReadKey(); break;
                default: Console.WriteLine("Opcion Invalida"); Console.ReadKey(); menu(); break;
            }
        }

    }
}