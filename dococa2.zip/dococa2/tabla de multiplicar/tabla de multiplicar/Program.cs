﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace TABLAS_DE_MULTIPLICAR
{
    class Program
    {
        static void Main(string[] args)
        {
            menu();
        }
        static void tablitas7w7()
        { 
            int NUM, RESUL, T, I; string linea; Console.Write("CUANTAS TABLAS: "); linea = Console.ReadLine(); NUM = int.Parse(linea); for (T = 1; T <= NUM; T++)
            {
                for (I = 10; I >= 1; I--)
                {
                    RESUL = T * I;


                    Console.WriteLine("{0} * {1} = {2}", T, I, RESUL);
                }
                Console.Write("Pulse una Tecla:"); Console.ReadLine();
            }
            Console.ReadKey();
        }
        static void menu()
        {
            int opcion;
            Console.WriteLine("MENU PRINCIPAL");
            Console.WriteLine("1. tablas de multiplicar");
            Console.WriteLine("2. salir");
            Console.WriteLine("Elija una Opcion");
            opcion = Convert.ToInt32(Console.ReadLine());
            switch (opcion)
            {
                case 1: tablitas7w7(); menu(); break;
                case 2: Console.WriteLine("Salida del Sistema"); Console.ReadKey(); break;
                default: Console.WriteLine("Opcion Invalida"); Console.ReadKey(); menu(); break;
            }
        }
}
}