﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ine
{
    class Program
    {
        static void Main(string[] args)
        {
            menu();
        }
        static void ines()
        {    
        int edad;
            {
                Console.WriteLine("Ingrese edad del usuario por favor");
                edad = Convert.ToInt32(Console.ReadLine());
                if (edad >= 0 && edad <= 120)
                    if (edad < 5)
                        Console.WriteLine("el uaurioo es un bebe ");
                    else
                        if (edad < 17)
                        Console.WriteLine("el usuario es un niño");
                    else
                            if (edad < 50)
                        Console.WriteLine("el usuario es un adulto");

                    else
                                    if (edad < 100
                        )
                        Console.WriteLine("el uauario es un anciano");


            }
                Console.ReadKey();
            }

        static void menu()
        {
            int opcion;
            Console.WriteLine("MENU PRINCIPAL");
            Console.WriteLine("1. REGISTRO DE INE");
            Console.WriteLine("2. salir");
            Console.WriteLine("Elija una Opcion");
            opcion = Convert.ToInt32(Console.ReadLine());
            switch (opcion)
            {
                case 1: ines(); menu(); break;
                case 2: Console.WriteLine("Salida del Sistema"); Console.ReadKey(); break;
                default: Console.WriteLine("Opcion Invalida"); Console.ReadKey(); menu(); break;
            }
        }
}
}
