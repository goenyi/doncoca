﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace equipodefut
{
    class Program
    {
        static void Main(string[] args)
        {
            menu();
        }

        static void equipsoka()
        {

            int resultado1, resultado2;
            string equipo1, equipo2;

            Console.WriteLine("Equipos que jugaron y sus resultados");
            Console.WriteLine("Ingrese nombre del primer equipo");
            equipo1 = (Console.ReadLine());
            Console.WriteLine("Ingrese marcador del primer equipo");
            resultado1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ingrese nombre del segundo equipo");
            equipo2 = (Console.ReadLine());
            Console.WriteLine("Ingrese marcador del segundo equipo");
            resultado2 = Convert.ToInt32(Console.ReadLine());



            if (resultado1 > resultado2)

                Console.WriteLine("el ganador es: " + equipo1);


            if (resultado2 > resultado1)


                Console.WriteLine("el ganador es: " + equipo2);



            if (resultado2 == resultado1)


                Console.WriteLine("ha sido un empate en los equipos: " + equipo2 + equipo1);



            Console.ReadKey();//pausa
        }
        static void menu()
        {
            int opcion;
            Console.WriteLine("MENU PRINCIPAL");
            Console.WriteLine("1. Resultado de los partidos de hoy");
            Console.WriteLine("2. salir");
            Console.WriteLine("Elija una Opcion");
            opcion = Convert.ToInt32(Console.ReadLine());
            switch (opcion)
            {
                case 1: equipsoka(); menu(); break;
                case 2: Console.WriteLine("Salida del Sistema"); Console.ReadKey(); break;
                default: Console.WriteLine("Opcion Invalida"); Console.ReadKey(); menu(); break;
            }

        }


    }
}