﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sueldoconextras
{
    class Program
    {
        static void Main(string[] args)
        {
            menu();
        }

        static void suelconex()
        { 
            int horas, ganohora;
            double sumaex, ganoextra;
            sumaex = 1.5;
            Console.WriteLine("Pago diario mas horas extras");
            Console.WriteLine("Ingrese horas trabajadas");
            horas = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ingrese el sueldo por hora del empleado");
            ganohora = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ingrese las horas extras trabajadas");
            ganoextra = Convert.ToInt32(Console.ReadLine());
            

            if (horas > 0) 
            {
                horas = horas*ganohora;
               
                Console.WriteLine("gana por horas: " + horas);
             
            }
            if (ganoextra > 0) 
            {
                ganoextra = (ganohora * sumaex);
        
                Console.WriteLine("gana por horas extras: " + ganoextra);

            }
            

            Console.ReadKey();//pausa
        }
        static void menu()
        {
            int opcion;
            Console.WriteLine("MENU PRINCIPAL");
            Console.WriteLine("1. Sueldo diario con Horas Extras");
            Console.WriteLine("2. salir");
            Console.WriteLine("Elija una Opcion");
            opcion = Convert.ToInt32(Console.ReadLine());
            switch (opcion)
            {
                case 1: suelconex(); menu(); break;
                case 2: Console.WriteLine("Salida del Sistema"); Console.ReadKey(); break;
                default: Console.WriteLine("Opcion Invalida"); Console.ReadKey(); menu(); break;
            }
        }

}
}