﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ecuacionCuadratica
{
    class Program
    {
        static void Main(string[] args)
        {
        
        

       
            int horas, ganohora;
            double sumaex, ganoextra;
            sumaex = 1.5;
            Console.WriteLine("Pago diario mas horas extras");
            Console.WriteLine("Ingrese horas trabajadas");
            horas = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ingrese el sueldo por hora del empleado");
            ganohora = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ingrese las horas extras trabajadas");
            ganoextra = Convert.ToInt32(Console.ReadLine());
            

            if (horas > 0) //calcular x1, x2
            {
                horas = horas*ganohora;
               
                Console.WriteLine("gana por horas: " + horas);
             
            }
            if (ganoextra > 0) //calcular x1, x2
            {
                ganoextra = (ganohora * sumaex);
        
                Console.WriteLine("gana por horas: " + ganoextra);

            }
            

            Console.ReadKey();//pausa
        }
    }
}
