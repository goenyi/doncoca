﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ine
{
    class Program
    {
        static void Main(string[] args)
        {
            int edad;
            {
                Console.WriteLine("Ingrese edad del usuario por favor");
                edad = Convert.ToInt32(Console.ReadLine());
                if (edad >= 0 && edad <= 120)
                    if (edad < 5)
                        Console.WriteLine("el uaurioo es un bebe ");
                    else
                        if (edad < 17)
                        Console.WriteLine("el usuario es un niño");
                    else
                            if (edad <50 )
                        Console.WriteLine("el usuario es un adulto");
                    
                    else
                                    if (edad < 100
                        )
                        Console.WriteLine("el uauario es un anciano");
                 


                Console.ReadKey();
            }
        }

    }
}

