﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int Cantidad, Q100, Q50, Q20, Q10, Q5; Q100 = 0; Q50 = 0; Q20 = 0; Q10 = 0; Q5 = 0; 
            string linea; Console.Write("DIGITE UNA CANTIDAD :"); 
            linea = Console.ReadLine(); 
            Cantidad = int.Parse(linea); 
            if ((Cantidad >= 100)) { Q100 = (Cantidad / 100); Cantidad = Cantidad - (Q100 * 100); }
            if ((Cantidad >= 50)) { Q50 = (Cantidad / 50); Cantidad = Cantidad - (Q50 * 50); }
            if ((Cantidad >= 20)) { Q20 = (Cantidad / 20); Cantidad = Cantidad - (Q20 * 20); }
            if ((Cantidad >= 10)) { Q10 = (Cantidad / 10); Cantidad = Cantidad - (Q10 * 10); }
            if ((Cantidad >= 5)) { Q5 = (Cantidad / 5); Cantidad = Cantidad - (Q5 * 5); }
            Console.WriteLine("BILLETES DE A 100: " + Q100); 
            Console.WriteLine("BILLETES DE A 50 : " + Q50); 
            Console.WriteLine("BILLETES DE A 20 : " + Q20);
            Console.WriteLine("BILLETES DE A 10 : " + Q10); 
            Console.WriteLine("BILLETES DE A 5 : " + Q5); 
            Console.WriteLine("BILLETES DE A 1 : " + Cantidad); 
            Console.Write("Pulse una Tecla:"); 
            Console.ReadLine();
        }
    }
}