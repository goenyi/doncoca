﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ecuacionCuadratica
{
    class Program
    {
        static void Main(string[] args)
        {
            memosapia();
        }
        static void anbisi()
        {
            int a;
            Console.WriteLine("Ingresa año");
            a = Convert.ToInt32(Console.ReadLine());
            if (a % 4 == 0 && (a % 100 != 0 || a % 400 == 0))
            {
                Console.WriteLine("El año " + a + " Si es bisiesto ");
            }
            else
            {
                Console.WriteLine("El año " + a + " No es bisiesto ");
            }
        }
            static double calcularDeterminante(int x) //funcion de parametros
            {
                double resultado;
                resultado = (Math.Pow(x, 2)) + (2 * x * 4)  + (Math.Pow(4,2));
                return resultado; //retorna como resultado el determinante
            }


        static void calcularFormula() //funcion de referencia
        {

            int x;
            double det, x1;
            Console.WriteLine("(x+4)^2");
            Console.WriteLine("Ingrese el valor de x");
            x = Convert.ToInt32(Console.ReadLine());
            det = calcularDeterminante(x);



            if (det > 0) //calcular x1, x2
            { 
                x1 = det;

            Console.WriteLine("X1: " + x1);
        }
                
            

                Console.ReadKey();//pausa
            }

            static void memosapia()
            {
                int opcion;
                Console.WriteLine("MENU PRINCIPAL");
                Console.WriteLine("1. saber si es un año bisiesto");
                Console.WriteLine("2. calcular formula cuadratica");
                Console.WriteLine("3. salir");
                Console.WriteLine("Elija una Opcion");
                opcion = Convert.ToInt32(Console.ReadLine());
                switch (opcion)
                {
                    case 1: anbisi(); memosapia(); break;
                    case 2: calcularFormula(); memosapia(); break;
                    case 3: Console.WriteLine("Salida del Sistema"); Console.ReadKey(); break;
                    default: Console.WriteLine("Opcion Invalida"); Console.ReadKey(); memosapia(); break;
                }

            }


        }
    }

    
