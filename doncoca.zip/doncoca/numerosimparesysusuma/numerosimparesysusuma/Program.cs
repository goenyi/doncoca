﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace SUMAIMPARES 
{
    class Program { static void Main(string[] args) 
        { 
            byte NUM, I; 
            int SUMP = 0; 
            string linea; 
            Console.Write("NÚMERO MÁXIMO: "); 
            linea = Console.ReadLine(); 
            NUM = byte.Parse(linea); 
            for (I = 1; I <= NUM; I += 2) 
            { SUMP = SUMP + I; }  
            Console.WriteLine("suma de numeros impares : " + SUMP);
            if (SUMP > 0) ;
            Console.WriteLine("numeros ingresados : " + linea);// no especifica el ejercicio si solo se quiere imprimir los numeros impares o todos en total... :)
            Console.Write("Pulse una Tecla:");
            Console.ReadLine(); }
    } 
}
